
from django.contrib import admin
from .models import Docente, Estudiante, Nota, Curso

admin.site.register(Docente)
admin.site.register(Estudiante)
admin.site.register(Nota)
admin.site.register(Curso)


# Register your models here.
