from django.apps import AppConfig


class Aplicacion1Config(AppConfig):
    name = 'Aplicacion1'
