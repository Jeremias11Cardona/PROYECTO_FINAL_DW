from django.forms import ModelForm
from django import forms
from .models import Docente, Estudiante, Nota, Curso

class DocenteForm(ModelForm):
	class Meta:
		model = Docente
		fields = '__all__'

		labels={
			'pnombre':'Primer Nombre',
			'snombre':'Segundo Nombre',
			'pApellido':'Primer Apellido',
			'sApellido':'SegundoApellido',
			'fNacimiento':'Fecha de Nacimiento',
			'direccion': 'Direccion',
			'correo':'Correo Electronico',
		}

		widgets = {
			'pnombre':forms.TextInput(attrs={'class':'form-control'}),
			'snombre': forms.TextInput(attrs={'class':'form-control'}),
			'pApellido': forms.TextInput(attrs={'class':'form-control'}),
			'sApellido': forms.TextInput(attrs={'class':'form-control'}),
			'fNacimiento': forms.TextInput(attrs={'class':'form-control'}),
			'direccion': forms.TextInput(attrs={'class':'form-control'}),
			'correo': forms.TextInput(attrs={'class':'form-control'}),
		}
class EstudianteForm(ModelForm):
	class Meta:
		model = Estudiante
		fields = '__all__'

		labels={
			'pnombre':'Primer Nombre',
			'snombre':'Segundo Nombre',
			'pApellido':'Primer Apellido',
			'sApellido':'SegundoApellido',
			'fNacimiento':'Fecha de Nacimiento',
			'direccion': 'Direccion',
			'correo':'Correo Electronico',
		}

		widgets = {
			'pnombre':forms.TextInput(attrs={'class':'form-control'}),
			'snombre': forms.TextInput(attrs={'class':'form-control'}),
			'pApellido': forms.TextInput(attrs={'class':'form-control'}),
			'sApellido': forms.TextInput(attrs={'class':'form-control'}),
			'fNacimiento': forms.TextInput(attrs={'class':'form-control'}),
			'direccion': forms.TextInput(attrs={'class':'form-control'}),
			'correo': forms.TextInput(attrs={'class':'form-control'}),
		}


class NotaForm(ModelForm):
	class Meta:
		model = Nota
		fields = '__all__'

		labels={
			'nota':'Nota',
			'curso':'Curso',
		}

		widgets = {
			'nota':forms.TextInput(attrs={'class':'form-control'}),
			'curso': forms.TextInput(attrs={'class':'form-control'}),
		}

class CursoForm(ModelForm):
	class Meta:
		model = Curso
		fields = '__all__'

		labels={
			'nombre':'Nombre del curso',
			'seccion':'Seccion',
		}

		widgets = {
			'nombre':forms.TextInput(attrs={'class':'form-control'}),
			'seccion': forms.TextInput(attrs={'class':'form-control'}),
		}