
from django.db import models

# Create your models here.
class Docente(models.Model):
	pnombre = models.CharField(max_length=25)
	snombre = models.CharField(max_length=25)
	pApellido = models.CharField(max_length=25)
	sApellido = models.CharField(max_length=25)
	fNacimiento= models.CharField(max_length=25)
	direccion= models.CharField(max_length=25)
	correo=models.CharField(max_length=25)

	def __str__(self):
		return '%s %s %s %s %s %s %s' % (self.pnombre,self.snombre, self.pApellido, self.sApellido, self.fNacimiento,self.direccion, self.correo)
 
class Estudiante(models.Model):
	pnombre = models.CharField(max_length=25)
	snombre = models.CharField(max_length=25)
	pApellido = models.CharField(max_length=25)
	sApellido = models.CharField(max_length=25)
	fNacimiento= models.CharField(max_length=25)
	direccion= models.CharField(max_length=25)
	correo=models.CharField(max_length=25)

	def __str__(self):
		return '%s %s %s %s %s %s %s' % (self.pnombre,self.snombre, self.pApellido, self.sApellido, self.fNacimiento,self.direccion, self.correo)


class Nota(models.Model):
	nota = models.CharField(max_length=25)
	curso = models.CharField(max_length=25)

	def __str__(self):
		return '%s %s' % (self.nota,self.curso)

class Curso(models.Model):
	nombre = models.CharField(max_length=25)
	seccion = models.CharField(max_length=25)

	def __str__(self):
		return '%s %s' % (self.nombre,self.seccion)
 