"""PrimerProyecto URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/2.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.conf.urls import url,include
from django.urls import path
from .views import IndexView, DocentesView, EstudiantesView, GaleriaView, InformacionView, AcercaView
urlpatterns = [
    path('', IndexView.as_view()), 
    path('Inicio/', IndexView.as_view(),name='Inicio'),
    path('Docentes/', DocentesView.as_view(),name='Docentes'),
    path('Estudiantes/', EstudiantesView.as_view(),name='Estudiantes'),
    path('Galeria/', GaleriaView.as_view(),name='Galeria'),
    path('Informacion/', InformacionView.as_view(),name='Informacion'),
    path('Acerca/',  AcercaView.as_view(),name='Acerca'),
]
