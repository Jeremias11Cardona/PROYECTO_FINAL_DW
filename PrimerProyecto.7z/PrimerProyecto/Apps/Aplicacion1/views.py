
from django.shortcuts import render
from django.views.generic import TemplateView, CreateView
from .forms import  DocenteForm, EstudianteForm, NotaForm, CursoForm
from .models import Docente, Estudiante, Nota, Curso
from django.urls import reverse_lazy


# Create your views here.
class IndexView(TemplateView):  
	  template_name='index.html'

class DocentesView(CreateView):  
	  template_name='docentes.html'
	  model =Docente
	  form_class= DocenteForm
	  success_url=reverse_lazy('app1:Docentes')


class EstudiantesView(CreateView):  
	  template_name='estudiantes.html'
	  model =Curso
	  form_class= CursoForm
	  success_url=reverse_lazy('app1:Estudiantes')	  

class GaleriaView(TemplateView):  
	  template_name='galeria.html'

class InformacionView(TemplateView):  
	  template_name='informacion.html'

class AcercaView(TemplateView):  
	  template_name='acerca.html'

	
 